var searchData=
[
  ['controlrequest_5ft_0',['controlRequest_t',['../class_m_d___m_a_x72_x_x.html#a7c6d702fe0161b19448f35049e00bf4f',1,'MD_MAX72XX']]],
  ['controlvalue_5ft_1',['controlValue_t',['../class_m_d___m_a_x72_x_x.html#aadaf745b81100652dafeff2eb212f457',1,'MD_MAX72XX']]]
];
